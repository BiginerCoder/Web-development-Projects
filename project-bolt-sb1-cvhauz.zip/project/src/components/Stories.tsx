import React from 'react';

export function Stories() {
  return (
    <div className="flex space-x-4 mb-6 overflow-x-auto pb-4">
      {[1, 2, 3, 4].map((item) => (
        <div key={item} className="flex-shrink-0 relative">
          <img
            src={`https://source.unsplash.com/random/200x300?sig=${item}`}
            className="w-32 h-48 rounded-xl object-cover"
            alt="Story"
          />
          <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/60 to-transparent rounded-b-xl">
            <p className="text-white text-sm font-medium">User Name</p>
          </div>
        </div>
      ))}
    </div>
  );
}