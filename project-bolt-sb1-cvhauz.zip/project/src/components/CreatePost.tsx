import React from 'react';
import { User, Video, Users } from 'lucide-react';

export function CreatePost() {
  return (
    <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
      <div className="flex items-center space-x-4">
        <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
          <User className="w-6 h-6 text-gray-600" />
        </div>
        <input
          type="text"
          placeholder="What's on your mind?"
          className="bg-gray-100 rounded-full py-2.5 px-4 flex-grow focus:outline-none"
        />
      </div>
      <div className="flex justify-between mt-4 pt-4 border-t">
        <button className="flex items-center space-x-2 text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-lg">
          <Video className="w-6 h-6" />
          <span>Live Video</span>
        </button>
        <button className="flex items-center space-x-2 text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-lg">
          <img src="https://source.unsplash.com/random/24x24" className="w-6 h-6 rounded" alt="" />
          <span>Photo/Video</span>
        </button>
        <button className="flex items-center space-x-2 text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-lg">
          <Users className="w-6 h-6" />
          <span>Tag Friends</span>
        </button>
      </div>
    </div>
  );
}