import React from 'react';
import { User, MessageCircle } from 'lucide-react';

interface PostProps {
  id: number;
}

export function Post({ id }: PostProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm mb-6">
      <div className="p-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
            <User className="w-6 h-6 text-gray-600" />
          </div>
          <div>
            <p className="font-semibold">John Doe</p>
            <p className="text-gray-500 text-sm">2 hours ago</p>
          </div>
        </div>
        <p className="mt-4">Having an amazing time exploring nature! 🌲</p>
      </div>
      <img
        src={`https://source.unsplash.com/random/800x600?nature,${id}`}
        className="w-full h-96 object-cover"
        alt="Post"
      />
      <div className="p-4">
        <div className="flex items-center justify-between pb-4 border-b">
          <div className="flex items-center space-x-2">
            <span className="bg-blue-500 text-white p-1 rounded-full">👍</span>
            <span className="text-gray-500">2.5K</span>
          </div>
          <div className="text-gray-500">
            <span>400 comments</span>
          </div>
        </div>
        <div className="flex justify-between pt-4">
          <button className="flex items-center space-x-2 text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-lg">
            <span>👍</span>
            <span>Like</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-lg">
            <MessageCircle className="w-5 h-5" />
            <span>Comment</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-lg">
            <span>↗️</span>
            <span>Share</span>
          </button>
        </div>
      </div>
    </div>
  );
}