import React from 'react';
import { Bell, Home, Menu, MessageCircle, Search, User, Users, Video } from 'lucide-react';

export function Navigation() {
  return (
    <nav className="bg-white shadow-md fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <span className="text-blue-600 text-3xl font-bold">facebook</span>
            <div className="ml-4 relative">
              <input
                type="text"
                placeholder="Search Facebook"
                className="bg-gray-100 rounded-full py-2 px-4 pl-10 w-72 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search className="absolute left-3 top-2.5 text-gray-500 w-5 h-5" />
            </div>
          </div>
          
          <div className="flex space-x-8">
            <Home className="w-6 h-6 text-blue-500" />
            <Video className="w-6 h-6 text-gray-500" />
            <Users className="w-6 h-6 text-gray-500" />
            <Menu className="w-6 h-6 text-gray-500" />
          </div>
          
          <div className="flex items-center space-x-4">
            <MessageCircle className="w-6 h-6 text-gray-600" />
            <Bell className="w-6 h-6 text-gray-600" />
            <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
              <User className="w-6 h-6 text-gray-600" />
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}