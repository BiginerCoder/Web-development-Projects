import React from 'react';
import { Navigation } from './components/Navigation';
import { Stories } from './components/Stories';
import { CreatePost } from './components/CreatePost';
import { Post } from './components/Post';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navigation />
      
      <div className="pt-20 max-w-2xl mx-auto px-4">
        <Stories />
        <CreatePost />
        {[1, 2, 3].map((id) => (
          <Post key={id} id={id} />
        ))}
      </div>
    </div>
  );
}

export default App;